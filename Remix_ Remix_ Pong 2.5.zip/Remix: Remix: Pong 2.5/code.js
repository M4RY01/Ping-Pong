var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["b9b2e860-cfdc-4a30-9e7e-f3276b85a589","23950295-38df-46ef-a750-9944eea3e847","813f2a87-070a-44d6-a657-0f6f72f81961"],"propsByKey":{"b9b2e860-cfdc-4a30-9e7e-f3276b85a589":{"name":"ball","sourceUrl":null,"frameSize":{"x":64,"y":64},"frameCount":1,"looping":true,"frameDelay":12,"version":"Z1rfCfyYnsHjjtQHnCo3zM_891Ov3J4N","loadedFromSource":true,"saved":true,"sourceSize":{"x":64,"y":64},"rootRelativePath":"assets/b9b2e860-cfdc-4a30-9e7e-f3276b85a589.png"},"23950295-38df-46ef-a750-9944eea3e847":{"name":"computer","sourceUrl":"assets/v3/animations/qsZf_Li2M73Z_ZA-t7UpBPq14KrvHzdkkHclU9Pkd7U/23950295-38df-46ef-a750-9944eea3e847.png","frameSize":{"x":64,"y":64},"frameCount":1,"looping":true,"frameDelay":4,"version":"Y6en4Y__GSpRqRBi.lHHir2vinqActs2","loadedFromSource":true,"saved":true,"sourceSize":{"x":64,"y":64},"rootRelativePath":"assets/v3/animations/qsZf_Li2M73Z_ZA-t7UpBPq14KrvHzdkkHclU9Pkd7U/23950295-38df-46ef-a750-9944eea3e847.png"},"813f2a87-070a-44d6-a657-0f6f72f81961":{"name":"player","sourceUrl":"assets/v3/animations/qsZf_Li2M73Z_ZA-t7UpBPq14KrvHzdkkHclU9Pkd7U/813f2a87-070a-44d6-a657-0f6f72f81961.png","frameSize":{"x":64,"y":64},"frameCount":1,"looping":true,"frameDelay":4,"version":"hPmMsE35UZ2wgjROei_wfULD0xe7bz70","loadedFromSource":true,"saved":true,"sourceSize":{"x":64,"y":64},"rootRelativePath":"assets/v3/animations/qsZf_Li2M73Z_ZA-t7UpBPq14KrvHzdkkHclU9Pkd7U/813f2a87-070a-44d6-a657-0f6f72f81961.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


var playerPaddle= createSprite(390,200,10,100);
    playerPaddle.shapeColor="blue";
    var computerPaddle= createSprite(10,200,10,100);
    computerPaddle.shapeColor="red";
    var ball= createSprite(200,200,15,15);
    ball.shapeColor="black";
    
    playerPaddle.setAnimation("player");
    computerPaddle.setAnimation("computer");
    ball.setAnimation("ball");

function draw() {
  background(rgb(48, 48, 48));
  
  if (keyDown("up")) {
    playerPaddle.y=playerPaddle.y-10;
  }
  
  if (keyDown("down")) {
    playerPaddle.y=playerPaddle.y+10;
  }
  if (keyDown("space")) {
    ball.velocityX=2;
    ball.velocityY=3;
  }
  
  if (ball.isTouching(computerPaddle)||ball.isTouching(playerPaddle)) 
  {
    playSound( "assets/category_pop/deep_bubble_notification.mp3");
    
  }
  
  
  computerPaddle.y=ball.y;

  
  createEdgeSprites();
  ball.bounceOff(topEdge);
  ball.bounceOff(bottomEdge);
  ball.bounceOff(computerPaddle);
  ball.bounceOff(playerPaddle);
  
  createEdgeSprites();
  playerPaddle.bounceOff(topEdge);
  playerPaddle.bounceOff(bottomEdge);
  
  
    
    if (ball.isTouching(rightEdge)||ball.isTouching(leftEdge)){
     playSound();
    }
  
  
  drawSprites();
  drawnet();
  
}

function drawnet(){
    for (var num = 0; num <=400; num+=20) {
    
  stroke("yellow");
  line(200,num,200,num+10);
  
  }
  
  
}



// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
